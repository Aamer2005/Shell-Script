#7. To display the date, time, user name and current directory. 
today=$(date)

echo "Current Date And Time : $today" 

echo "UserName : $USERNAME"
echo "Present Working Directory : $(pwd)"
