#6. Script to calculate age of user in years.

echo "Enter Your Age : "
read -p "Enter Year : " year
read -p "Enter Month : " month
read -p "Enter Day : " Day

age=$((2025-year))

echo "You Are $age Year Old"

