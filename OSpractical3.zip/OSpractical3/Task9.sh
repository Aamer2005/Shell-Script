#9. Shell Script to create and print the value of variables

read -p "Enter Name:" name
read -p "Enter Age:" Age

college="SGGSIE&T"
fees=82378

echo "Name : $name"
echo "Age : $Age"
echo "College : $college"
echo "Fees : $fees"
