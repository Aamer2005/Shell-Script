#5. Script for addition of  two numbers

read -p "Enter number 1 : " num1
read -p "Enter number 2 : " num2

sum=$(($num1+$num2))

echo "SUM : $sum"
