#3. Shell script to accept value of variables form user.

read -p "Enter Name : " value1
read -p "Enter Age : " Value2
read -p "Enter Registeration No : " value3

echo 
echo "INFORMATION"
echo "__________________________________"

echo "Name : $value1"
echo "Age : $Value2"
echo "Reg. No : value3" 

echo "___________________________________"
